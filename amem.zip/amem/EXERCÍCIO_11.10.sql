-- Exercício 10

DELIMITER $$
create procedure spInsert_tbVendas(
	vNumeroVenda int,
	vCliente varchar(200),
    vCodigoBarras decimal(14,0),
    vQtd int,
    vTotalVenda decimal (10,2)
)

BEGIN
declare vIdCliente int;
declare vValorItem decimal(6,2);

-- checar se o cliente existe
if exists(select 1 from tbCliente where NomeCli = vCliente) and
exists (select 1 from tbProduto where CodigoBarras = vCodigoBarras) then

set vIdCliente = (select Id from tbCliente where NomeCli = vCliente);
-- o valor de IdCliente é definido pelo Id da tbCliente onde o NomeCli tem q ser igual ao que a variável temporária armazenar
set vValorItem = (select Valor from tbProduto where CodigoBarras = vCodigoBarras);
-- o valor de vValorItem é definido pelo Valor da tbProduto onde CodigoBarras tem q bater com o valor da vCodigoBarras.*/
set vTotalVenda = (vValorItem * vQtd);
 -- checar para evitar o erro de que o TotalVenda da null

insert into tbVenda(Id_Cli, NumeroVenda, DataVenda, TotalVenda) values
(vIdCliente, vNumeroVenda, curdate(), vTotalVenda);

insert into tbItemVenda(NumeroVenda, CodigoBarras, ValorItem, Qtd) 
values (vNumeroVenda, vCodigoBarras, vValorItem, vQtd);

end if;

end $$

DELIMITER ;

call spInsert_tbVendas(1, "Pimpão", 12345678910111, 1, 0);
call spInsert_tbVendas(2, "Lança Perfume", 12345678910112, 2, 0);
call spInsert_tbVendas(3, "Pimpão", 12345678910113, 1, 0);