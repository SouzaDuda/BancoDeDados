DELIMITER $$

create procedure spInsert_tbNotaFiscal(
    vNF int,
    vCliente varchar(200)
)

BEGIN

declare vIdCliente int;
declare vTotalNota decimal(10,2);

-- Buscar Id do cliente
set vIdCliente = (select Id from tbCliente where NomeCli = vCliente);

-- Verificar se existe venda desse cliente
if exists(select 1 from tbVenda where Id_Cli = vIdCliente) then

    -- Somar total das vendas do cliente
    select sum(TotalVenda) into vTotalNota
    from tbVenda 
    where Id_Cli = vIdCliente;

    -- Inserir nota fiscal
    insert into tbNota_fiscal(NF, DataEmissao, TotalNota)
    values(vNF, curdate(), vTotalNota);

end if;

END $$

DELIMITER ;

call spInsert_tbNotaFiscal(359, 'Pimpão');
call spInsert_tbNotaFiscal(360, 'Lança Perfume');

select * from tbNota_fiscal;

