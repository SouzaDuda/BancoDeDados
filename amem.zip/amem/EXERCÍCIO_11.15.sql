-- Exercício 11.15

DELIMITER $$

create procedure spSelectProdutos()
BEGIN
    select * from tbProduto;
end $$

DELIMITER ;




show tables;
select * from tbEndereco;
select * from tbProduto;
select * from tbCliente;
select * from tbClientePF;
select * from tbClientePJ;
select * from tbCompra;

select NotaFiscal, date_format(DataCompra, '%d/%m/%Y') as DataCompraBR, ValorTotal, QtdTotal, Codigo from tbCompra;
select * from tbItemCompra;
select * from tbVenda;
select * from tbItemVenda;

select NumeroVenda, date_format(DataVenda, '%d/%m/%Y') as DataVendaBR, TotalVenda from tbVenda;
select * from tbNota_fiscal;
select * from tbProduto;