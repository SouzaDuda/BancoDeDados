DELIMITER $$

create procedure spDelete_tbProduto(
	vCodigoBarras decimal(14,0)
)

BEGIN 

if exists (select 1 from tbProduto where CodigoBarras = vCodigoBarras) then

delete from tbProduto
where CodigoBarras = vCodigoBarras;

end if;

end $$

DELIMITER ;

call spDelete_tbProduto(12345678910116);
call spDelete_tbProduto(12345678910117);


select *
from tbProduto;