DELIMITER $$

create procedure spInsertProdutos_tbProduto(
	vCodigoBarras decimal(14,0),
	vNome varchar(200),
	vValorUnit decimal(10,2),
	vQtd int
)

BEGIN

if not exists(select CodigoBarras from tbProduto where CodigoBarras = vCodigoBarras) then
	insert into tbProduto(CodigoBarras, Nome, Valor, Qtd)
	values(vCodigoBarras, vNome, vValorUnit, vQtd);

end if;

end $$

DELIMITER ;

call spInsert_tbProduto(12345678910130, 'Camiseta de Poliéster', '35.61', 100);
call spInsert_tbProduto(12345678910131, 'Blusa Frio Moletom', '200.00', 100);
call spInsert_tbProduto(12345678910132, 'Vestido Decote Redondo', '144.00', 50);

select * from tbproduto;