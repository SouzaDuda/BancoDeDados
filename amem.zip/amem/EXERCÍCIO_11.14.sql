DELIMITER $$

create procedure spUpdate_tbProduto(
	vCodigoBarras decimal(14,0),
	vNome varchar(200),
	vValorUnit decimal(10,2)
)

BEGIN

if exists (select CodigoBarras from tbProduto where CodigoBarras = vCodigoBarras) then

update tbProduto set 
	Nome = vNome,
	Valor = vValorUnit

where CodigoBarras = vCodigoBarras;

end if;

end $$

DELIMITER ;

call spUpdate_tbProduto(12345678910111, 'Rei de Papel Mache', 64.50);
call spUpdate_tbProduto(12345678910112, 'Bolinha de Sabão', 120.00);
call spUpdate_tbProduto(12345678910113, 'Carro Bate Bate', 64.00 );

select * from tbProduto;