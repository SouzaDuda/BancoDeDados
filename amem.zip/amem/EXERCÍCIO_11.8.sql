use dbDistribuidora;
-- set sql_safe_updates = 0;
-- >>> (8)

Delimiter $$
Create procedure spInsert_ClientePJ(vNomeCli varchar(200), vCNPJ bigint, vIE bigint, vCEP decimal(8,0), vLogradouro char(200),
 vNumEnd decimal(6,0), vCompEnd varchar(50),  vBairro varchar(200), vCidade varchar(200), vUF char(2))
BEGIN

if not exists (select CidadeId from tbCidade where Cidade = vCidade) then -- Se não existir esse cidade, irá adicionar um novo
 call spInsert_tbCidade(vCidade);
end if;

if not exists (select BairroId from tbBairro where Bairro = vBairro) then -- Se não existir esse bairro, irá adicionar um novo
 call spInsert_tbBairro(vBairro);
end if;

if not exists (select UFId from tbEstado where UF = vUf) then
call spInsert_tbEstado(vUf);
end if;

if not exists (select UFId from tbEstado where UF = vUf) then
call spInsert_tbBairro(vUf);
end if;

if not exists (select CEP from tbEndereco where CEP = vCEP) then
insert into tbEndereco(Logradouro, BairroId, CidadeId, UFId, CEP)	
	values(
    vLogradouro, 
    (Select BairroId from tbBairro where Bairro = vBairro),
    (Select CidadeId from tbCidade where Cidade = vCidade), 
    (Select UFId from tbEstado where UF = vUF), 
    vCEP
    );
end if;

    insert into tbClientePJ(CNPJ, IE)
    Values(vCNPJ, vIE);
    
    insert into tbCliente(NomeCli, NumEnd, CompEnd, CepCli)
    values(vNomeCli, vNumEnd, vCompEnd, vCEP);
end $$

call spInsert_ClientePJ("Paganada", 12345678912345, 98765432198, 12345051, "Av Brasil", 159, Null, "Lapa", "Campinas", "SP");
call spInsert_ClientePJ("Caloteando", 12345678912346, 98765432199, 12345053, "Av Paulista", 69, Null, "Penha", "Rio de Janeiro", "RJ");
call spInsert_ClientePJ("Semgrana", 12345678912347, 98765432100, 12345060, "Rua dos Amores", 189, Null, "Sei Lá", "Recife", "PE");
call spInsert_ClientePJ("Cemreais", 12345678912348, 98765432101, 12345060, "Rua dos Amores", 5024, "Sala 23", "Sei Lá", "Recife", "PE");
call spInsert_ClientePJ("Durango", 12345678912349, 98765432102, 12345060, "Rua dos Amores", 1254, Null, "Sei Lá", "Recife", "PE");

-- delete from tbClientePJ;

select *
from tbClientePJ;
select *
from tbCliente;
