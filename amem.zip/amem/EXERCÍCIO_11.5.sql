use dbDistribuidora;
-- >>> Insert procedure tbProduto (5)

Delimiter $$

create procedure spInsert_tbProduto(vCodigoBarras decimal(14,0),vNome varchar(200), vValor decimal(10,2), vQtd int)

BEGIN

insert into  tbProduto(CodigoBarras, Nome, Valor, Qtd) 
	values (vCodigoBarras, vNome, vValor, vQtd);

end $$

call spInsert_tbProduto(12345678910111, 'Rei de Papel Mache', 54.61, 120);
call spInsert_tbProduto(12345678910112, 'Bolinha de Sabão', 100.45, 120);
call spInsert_tbProduto(12345678910113, 'Carro Bate', 44.00, 120);
call spInsert_tbProduto(12345678910114, 'Bola Furada', 10.00, 120);
call spInsert_tbProduto(12345678910115, 'Maçã Laranja', 99.44, 120);
call spInsert_tbProduto(12345678910116, 'Boneco do Hitler', 124.00, 200);
call spInsert_tbProduto(12345678910117, 'Farinha de Suruí', 50.00, 200);
call spInsert_tbProduto(12345678910118, 'Zelador de Cemitério', 24.50, 100);

-- drop procedure spInsert_tbProduto;

select * from tbProduto;