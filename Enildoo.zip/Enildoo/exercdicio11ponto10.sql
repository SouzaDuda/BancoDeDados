create database dbDistribuidora;
use dbDistribuidora;

set sql_safe_updates = 0;

create table tbCliente(
	Id int primary key auto_increment,
    NomeCli varchar(200) not null,
    NumEnd decimal(6,0) not null,
    CompEnd varchar(50),
    CepCli decimal(8,0),
    
    foreign key (CepCli) references tbEndereco(CEP)
);

create table tbClientePF(
	CPF decimal(11,0) primary key,
    RG decimal(9,0) not null,
    RG_Dig varchar(1),
    Nasc date not null
);

create table tbClientePJ(
	CNPJ decimal(14,0) primary key,
    IE decimal(11,0) unique
);

create table tbEndereco(
	Logradouro varchar(200) not null,
    CEP decimal(8,0) primary key,
    BairroId int not null,
    CidadeId int not null,
    UFId int not null,
    
    foreign key (BairroId) references tbBairro(BairroId),
    foreign key (CidadeId) references tbCidade(CidadeId),
    foreign key (UFId) references tbEstado(UFId)
);

create table tbBairro(
	BairroId int primary key auto_increment,
    Bairro varchar(200) not null
);

create table tbCidade(
	CidadeId int primary key auto_increment,
    Cidade varchar(200) not null
);

create table tbEstado(
	UFId int primary key auto_increment,
	UF varchar(2) not null
);

create table tbFornecedor(
	Codigo int primary key auto_increment,
    CNPJ decimal(14,0) unique,
    Nome varchar(200) not null,
    Telefone decimal(11,0)
);

create table tbProduto(
	CodigoBarras decimal(14,0) primary key,
    Nome varchar(200) not null,
    Valor decimal(10,2) not null,
    Qtd int
);

create table tbCompra(
	NotaFiscal int primary key,
    DataCompra date not null,
    ValorTotal decimal(10,2) not null,
    QtdTotal int not null,
    Codigo decimal(10,0),
    
    foreign key(Codigo) references tbFornecedor(Codigo)
);

create table tbItemCompra(
	NotaFiscal int primary key,
    CodigoBarras decimal(14,0) primary key,
    ValorItem decimal(10,2) not null,
    Qtd int not null,
    
    foreign key(NotaFiscal) references tbCompra(NotaFiscal),
    foreign key(CodigoBarras) references tbProduto(CodigoBarras)
    
);

-- alter table tbItemCompra add foreign key(NotaFiscal) references tbCompra(NotaFiscal);
-- alter table tbItemCompra add foreign key(CodigoBarras) references tbProduto(CodigoBarras);

create table tbVenda(
	NumeroVenda int primary key,
    DataVenda date not null,
    TotalVenda decimal(10,2) not null,
    Id_cli decimal(11,0) not null,
    NF int not null,
    
    foreign key(Id_Cli) references tbCliente(Id),
    foreign key(NF) references tbNota_Fiscal(NF)
);

create table tbItemVenda(
	NumeroVenda int primary key,
    CodigoBarras decimal(14,0) primary key,
    ValorItem decimal(6,2) not null,
    Qtd int not null,
    
    foreign key(NumeroVenda) references tbVenda(NumeroVenda),
    foreign key(CodigoBarras) references tbItemCompra(CodigoBarras)
);

create table tbNota_fiscal(
	NF int primary key,
    TotalNota decimal(10,2) not null,
    DataEmissao date not null
);

alter table tbFornecedor modify Telefone bigint;

-- DML
-- >>> Insert tbFornecedor (1)

insert into tbFornecedor values
(1, 1245678932123,'Revenda Chico Loco',11934567897),
(2, 1345678937123,'José Faz Tudo S/A', 1345678937123),
(3,1445678937123,'Vadalto Entregas', 11934567899),
(4, 1545678937123, 'Astrogildo das Estrelas', 11934567800),
(5, 1645678937123, 'Amoroso e Doce', 11934567801),
(6, 1745678937123,'Marcelo Dedal', 1134567802),
(7, 1845678937123,'Franciscano Cachaça', 11934567803),
(8, 1945678937123,'Joãozinho Chupeta', 1134567804);

select * from tbFornecedor;

-- >>> Insert procedure tbCidade (2)

Delimiter $$

create procedure spInsert_tbCidade(vCidadeId int,vCidade varchar(200))

BEGIN

insert into tbCidade (CidadeId, Cidade) 
	values (vCidadeId, vCidade);

end $$

call spInsert_tbCidade(1, 'Rio de Janeiro');
call spInsert_tbCidade(2, 'São Carlos');
call spInsert_tbCidade(3, 'Campinas');
call spInsert_tbCidade(4, 'Franco da Rocha');
call spInsert_tbCidade(5, 'Osasco');
call spInsert_tbCidade(6, 'Pirituba');
call spInsert_tbCidade(7, 'Lapa');
call spInsert_tbCidade(8, 'Ponta Grossa');

 select * from tbcidade;

-- DELETE FROM tbcidade;

-- drop procedure spInsert_tbCidade;

-- >>> Insert procedure tbEstado (3)

Delimiter $$

create procedure spInsert_tbEstado(vUF_Id int,vUF varchar(2))

BEGIN

insert into tbEstado (UFId, UF) 
	values (vUF_Id, vUF);

end $$

call spInsert_tbEstado(1, 'SP');
call spInsert_tbEstado(2,'RJ');
call spInsert_tbEstado(3,'RS');

select * from tbEstado;

-- >>> Insert procedure tbBairro (4)

Delimiter $$

create procedure spInsert_tbBairro(vBairroId int,vBairro varchar(200))

BEGIN

insert into tbBairro (BairroId, Bairro) 
	values (vBairroId, vBairro);

end $$

call spInsert_tbBairro(1, 'Aclimação');
call spInsert_tbBairro(2,'Capão Redondo');
call spInsert_tbBairro(3,'Pirituba');
call spInsert_tbBairro(4,'Liberdade');

select * from tbBairro;

-- >>> Insert procedure tbProduto (5)

Delimiter $$

create procedure spInsert_tbProduto(vCodigoBarras decimal(14,0),vNome varchar(200), vValor decimal(10,2), vQtd int)

BEGIN

insert into tbBairro (CodigoBarras, Nome, Valor, Qtd) 
	values (vCodigoBarras, vNome, vValor, vQtd);

end $$

call spInsert_tbProduto(12345678910111, 'Rei de Papel Mache', 54.61, 120);
call spInsert_tbProduto(12345678910112, 'Bolinha de Sabão', 100.45, 120);
call spInsert_tbProduto(12345678910113, 'Carro Bate', 44.00, 120);
call spInsert_tbProduto(12345678910114, 'Bola Furada', 10.00, 120);
call spInsert_tbProduto(12345678910115, 'Maçã Laranja', 99.44, 120);
call spInsert_tbProduto(12345678910116, 'Boneco do Hitler', 124.00, 200);
call spInsert_tbProduto(12345678910117, 'Farinha de Suruí', 50.00, 200);
call spInsert_tbProduto(12345678910118, 'Zelador de Cemitério', 24.50, 100);

select * from tbProduto;

Delimiter $$

create procedure spInsert_tbEstado(vUF_Id int,vUF varchar(2)) 
BEGIN

insert into tbEstado (UFId, UF) /* As colunas que criamos na tabela no create */
	values (vUF_Id, vUF); /*As variáveis temporárias que serão relacionadas EM ORDEM com as colunas da tabela*/

end $$

-- <<< Aqui vc chama a procedure e coloca em parênteses os dados

call spInsert_tbEstado(1, 'SP');
call spInsert_tbEstado(2,'RJ');
call spInsert_tbEstado(3,'RS');

select * from tbEstado;

-- >>> Insert procedure tbEndereco (6)

Delimiter $$

Create procedure spInsert_tbEndereco(
    vLogradouro varchar(200), 
    vBairro varchar(200), 
    vCidade varchar(200), 
    vUF char(2), 
    vCEP decimal(8,0)
)
BEGIN

    IF NOT EXISTS (SELECT BairroId FROM tbBairro WHERE Bairro = vBairro) THEN
        CALL spInsert_tbBairro(vBairro);
    END IF;

    IF NOT EXISTS (SELECT CidadeId FROM tbCidade WHERE Cidade = vCidade) THEN
        CALL spInsert_tbCidade(vCidade);
    END IF;

    IF NOT EXISTS (SELECT UFId FROM tbEstado WHERE UF = vUF) THEN
        CALL spInsert_tbEstado(vUF);
    END IF;

    INSERT INTO tbEndereco (Logradouro, BairroId, CidadeId, UFId, CEP)
    VALUES (
        (SELECT Logradouro from tbFornecedor where Logradouro = vLogradouro,
        (SELECT BairroId FROM tbBairro WHERE Bairro = vBairro),
        (SELECT CidadeId FROM tbCidade WHERE Cidade = vCidade),
        (SELECT UFId FROM tbEstado WHERE UF = vUF),
        vCEP
    );

END $$
Delimiter ;
drop procedure spInsert_tbEndereco;

call spInsert_tbEndereco('Rua da Federal', 'Lapa', 'São Paulo', 'SP', 12345050);

call spInsert_tbEndereco('Av Brasil', 'Lapa', 'Campinas', 'SP', 12345051);

call spInsert_tbEndereco('Rua Liberdade', 'Consolação', 'São Paulo', 'SP', 12345052);

call spInsert_tbEndereco('Av Paulista', 'Penha', 'Rio de Janeiro', 'RJ', 12345053);

call spInsert_tbEndereco('Rua Ximbú', 'Penha', 'Rio de Janeiro', 'RJ', 12345054);

call spInsert_tbEndereco('Rua Piu XI', 'Penha', 'Campinas', 'SP', 12345055);

call spInsert_tbEndereco('Rua Chocolate', 'Aclimação', 'Barra Mansa', 'RJ', 12345056);

call spInsert_tbEndereco('Rua Pão na Chapa', 'Barra Funda', 'Ponta Grossa', 'RS', 12345057);

-- >>> Insert procedure (7)

Create procedure InserirClientePF(VarNomeCli varchar(200), VarNumEnd decimal(6,0), VarCompEnd varchar(50), VarCEP decimal(8,0), VarCPF bigint, VarRG int, VarRGDig char(1), VarNasc date, VarLogradouro char(200), VarBairro varchar(200), VarCidade varchar(200), VarUF char(2))
BEGIN

if not exists (select CidadeId from tbCidade where Cidade = VarCidade) then -- Se não existir esse cidade, irá adicionar um novo
 call InserirCidade(VarCidade);
end if;

if not exists (select BairroId from tbBairro where Bairro = VarBairro) then -- Se não existir esse bairro, irá adicionar um novo
 call InserirBairro(VarBairro);
end if;

if not exists (select UFId from tbEstado where UF = VarUf) then
call inserirEstado(VarUf);
end if;

if not exists (select CEP from tbEndereco where CEP = VarCEP) then
insert into tbEndereco(Logradouro, BairroId, CidadeId, UFId, CEP)	
	values(
    VarLogradouro, 
    (Select BairroId from tbBairro where Bairro = VarBairro),
    (Select CidadeId from tbCidade where Cidade = VarCidade), 
    (Select UFId from tbEstado where UF = VarUF), 
    VarCEP
    );
end if;

insert into tbCliente(NomeCli, NumEnd, CompEnd, CepCli)
values(VarNomeCli, VarNumEnd, VarCompEnd, VarCEP);

insert into tbClientePF
values(VarCPF, VarRG, VarRGDIG, VarNasc, null);
end $$
CALL InserirClientePF('Pimpão', 325, NULL, 12345051, 12345678911, 12345678, '0', '2000-10-12', 'Av Brasil', 'Lapa', 'Campinas', 'SP');
CALL InserirClientePF('Disney Chaplin', 89, 'Ap. 12', 12345053, 12345678912, 12345679, '0', '2001-11-21', 'Av Paulista', 'Penha', 'Rio de Janeiro', 'RJ');
CALL InserirClientePF('Marciano', 744, NULL, 12345054, 12345678913, 12345680, '0', '2001-06-01', 'Rua Ximbú', 'Penha', 'Rio de Janeiro', 'RJ');
CALL InserirClientePF('Lança Perfume', 128, NULL, 12345059, 12345678914, 12345681, 'X', '2004-04-05', 'Rua Veia', 'Jardim Santa Isabel', 'Cuiabá', 'MT');
CALL InserirClientePF('Remédio Amargo', 2585, NULL, 12345058, 12345678915, 12345682, '0', '2002-07-15','Av Nova', 'Jardim Santa Isabel', 'Cuiabá', 'MT');

select * 
from tbCliente;

select * 
from tbClientePF;

-- >>> (8)

Delimiter $$
Create procedure spInsert_ClientePJ(vNomeCli varchar(200), vCNPJ bigint, vIE bigint, vCEP decimal(8,0), vLogradouro char(200),
 vNumEnd decimal(6,0), vCompEnd varchar(50),  vBairro varchar(200), vCidade varchar(200), VarUF char(2))
BEGIN

if not exists (select CidadeId from tbCidade where Cidade = VarCidade) then -- Se não existir esse cidade, irá adicionar um novo
 call spInsert_tbCidade(vCidade);
end if;

if not exists (select BairroId from tbBairro where Bairro = VarBairro) then -- Se não existir esse bairro, irá adicionar um novo
 call InserirBairro(vBairro);
end if;

if not exists (select UFId from tbEstado where UF = VarUf) then
call spInsert_tbEstado(vUf);
end if;

if not exists (select UFId from tbEstado where UF = VarUf) then
call spInsert_tbBairro(vUf);
end if;

if not exists (select CEP from tbEndereco where CEP = VarCEP) then
insert into tbEndereco(Logradouro, BairroId, CidadeId, UFId, CEP)	
	values(
    VarLogradouro, 
    (Select BairroId from tbBairro where Bairro = VarBairro),
    (Select CidadeId from tbCidade where Cidade = VarCidade), 
    (Select UFId from tbEstado where UF = VarUF), 
    VarCEP
    );
end if;

    insert into tbClientePJ(CNPJ, IE)
    Values(VarCNPJ, VarIE);
    
    insert into tbCliente(NomeCli, NumEnd, CompEnd, CepCli)
    values(VarNomeCli, VarNumEnd, VarCompEnd, VarCEP);
end $$

call spInsert_ClientePJ("Paganada", 12345678912345, 98765432198, 12345051, "Av Brasil", 159, Null, "Lapa", "Campinas", "SP");
call spInsert_ClientePJ("Caloteando", 12345678912346, 98765432199, 12345053, "Av Paulista", 69, Null, "Penha", "Rio de Janeiro", "RJ");
call spInsert_ClientePJ("Semgrana", 12345678912347, 98765432100, 12345060, "Rua dos Amores", 189, Null, "Sei Lá", "Recife", "PE");
call spInsert_ClientePJ("Cemreais", 12345678912348, 98765432101, 12345060, "Rua dos Amores", 5024, "Sala 23", "Sei Lá", "Recife", "PE");
call spInsert_ClientePJ("Durango", 12345678912349, 98765432102, 12345060, "Rua dos Amores", 1254, Null, "Sei Lá", "Recife", "PE");

select *
from tbClientePJ;
select *
from tbCliente;

-- >>> 10?
DELIMITER $$
CREATE PROCEDURE sp_insereVenda( IN num INTEGER, IN cliente INTEGER, IN cod BIGINT, IN qtd INTEGER )
BEGIN
    INSERT INTO tb_Venda (num_venda, cliente_id, data_venda, total_venda) SELECT num, cliente, CURDATE(), valor * qtd FROM tb_Produto WHERE cod_barras = cod;
    INSERT INTO tb_ItemVenda (num_venda, cod_barras, valor_item, qtd) SELECT num, cod, valor, qtd FROM tb_Produto WHERE cod_barras = cod;
END $$
DELIMITER ;

CALL sp_insereVenda(1, 1, 12345678910111, 1);
CALL sp_insereVenda(2, 4, 12345678910112, 2);
CALL sp_insereVenda(3, 1, 12345678910113, 1);

DELIMITER $$
CREATE PROCEDURE sp_insereNF( IN nf INTEGER, IN cliente INTEGER )
BEGIN
    INSERT INTO tb_NotaFiscal (NF, total_nota, data_emissao) SELECT nf, SUM(total_venda), CURDATE() FROM tb_Venda WHERE cliente_id = cliente;
END $$
DELIMITER ;

CALL sp_insereNF(359, 1);
CALL sp_insereNF(360, 4);

CALL sp_insereProduto(12345678910130, 'Camiseta de Poliéster', 35.61, 100);
CALL sp_insereProduto(12345678910131, 'Blusa Frio Moletom', 200.00, 100);
CALL sp_insereProduto(12345678910132, 'Vestido Decote Redondo', 144.00, 50);

DELIMITER $$
CREATE PROCEDURE sp_deletaProduto( IN cod BIGINT )
BEGIN
    DELETE FROM tb_Produto WHERE cod_barras = cod;
END $$
DELIMITER ;

CALL sp_deletaProduto(12345678910116);
CALL sp_deletaProduto(12345678910117);

DELIMITER $$
CREATE PROCEDURE sp_atualizaProduto( IN cod BIGINT, IN novo_nome VARCHAR(200), IN novo_valor DECIMAL(12,2) )
BEGIN
    UPDATE tb_Produto SET nome = novo_nome, valor = novo_valor WHERE cod_barras = cod;
END $$
DELIMITER ;

CALL sp_atualizaProduto(12345678910111, 'Rei de Papel Mache', 64.50);
CALL sp_atualizaProduto(12345678910112, 'Bolinha de Sabão', 120.00);
CALL sp_atualizaProduto(12345678910113, 'Carro Bate Bate', 64.00);

DELIMITER $$
CREATE PROCEDURE sp_listaProdutos()
BEGIN
    SELECT * FROM tb_Produto;
END $$
DELIMITER ;

CALL sp_listaProdutos();
