use dbDistribuidora;
-- >>> Insert procedure tbBairro (4)

Delimiter $$

create procedure spInsert_tbBairro(vBairro varchar(200))

BEGIN

insert into tbBairro (Bairro) 
	values (vBairro);

end $$

call spInsert_tbBairro('Aclimação');
call spInsert_tbBairro('Capão Redondo');
call spInsert_tbBairro('Pirituba');
call spInsert_tbBairro('Liberdade');

select * from tbBairro;

