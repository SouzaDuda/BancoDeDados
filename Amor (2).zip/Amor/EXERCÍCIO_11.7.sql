
use dbDistribuidora;
-- >>> Insert procedure (7)

Delimiter $$
create procedure spInsert_tbClientePF(vNomeCli varchar(200), vNumEnd decimal(6,0), vCompEnd varchar(50), vCEP decimal(8,0), vCPF bigint, 
vRG int, vRGDig char(1), vNasc date, vLogradouro char(200), vBairro varchar(200), vCidade varchar(200), vUF char(2))

BEGIN

if not exists (select CidadeId from tbCidade where Cidade = vCidade) then -- Se não existir esse cidade, irá adicionar um novo
	call spInsert_tbCidade(vCidade);
end if;

if not exists (select BairroId from tbBairro where Bairro = vBairro) then -- Se não existir esse bairro, irá adicionar um novo
	call spInsert_tbBairro(vBairro);
end if;

if not exists (select UFId from tbEstado where UF = vUf) then
	call spInsert_tbEstado(vUF);
end if;

if not exists (select CEP from tbEndereco where CEP = vCEP) then

insert into tbEndereco(Logradouro, BairroId, CidadeId, UFId, CEP)	
	values(
    vLogradouro, 
    (Select BairroId from tbBairro where Bairro = vBairro),
    (Select CidadeId from tbCidade where Cidade = vCidade), 
    (Select UFId from tbEstado where UF = vUF), 
    vCEP
    );
end if;

insert into tbCliente(NomeCli, NumEnd, CompEnd, CepCli)
values(vNomeCli, vNumEnd, vCompEnd, vCEP);

insert into tbClientePF
values(vCPF, vRG, vRGDig, vNasc);
end $$

CALL spInsert_tbClientePF('Pimpão', 325, NULL, 12345051, 12345678911, 12345678, '0', '2000-10-12', 'Av Brasil', 'Lapa', 'Campinas', 'SP');
CALL spInsert_tbClientePF('Disney Chaplin', 89, 'Ap. 12', 12345053, 12345678912, 12345679, '0', '2001-11-21', 'Av Paulista', 'Penha', 'Rio de Janeiro', 'RJ');
CALL spInsert_tbClientePF('Marciano', 744, NULL, 12345054, 12345678913, 12345680, '0', '2001-06-01', 'Rua Ximbú', 'Penha', 'Rio de Janeiro', 'RJ');
CALL spInsert_tbClientePF('Lança Perfume', 128, NULL, 12345059, 12345678914, 12345681, 'X', '2004-04-05', 'Rua Veia', 'Jardim Santa Isabel', 'Cuiabá', 'MT');
CALL spInsert_tbClientePF('Remédio Amargo', 2585, NULL, 12345058, 12345678915, 12345682, '0', '2002-07-15','Av Nova', 'Jardim Santa Isabel', 'Cuiabá', 'MT');

select * 
from tbCliente;

select * 
from tbClientePF;