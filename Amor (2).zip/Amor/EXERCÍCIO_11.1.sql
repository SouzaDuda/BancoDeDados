use dbDistribuidora;
-- DML
-- >>> Insert tbFornecedor (1)

insert into tbFornecedor values
(1, 1245678932123,'Revenda Chico Loco',11934567897),
(2, 1345678937123,'José Faz Tudo S/A', 1345678937123),
(3,1445678937123,'Vadalto Entregas', 11934567899),
(4, 1545678937123, 'Astrogildo das Estrelas', 11934567800),
(5, 1645678937123, 'Amoroso e Doce', 11934567801),
(6, 1745678937123,'Marcelo Dedal', 1134567802),
(7, 1845678937123,'Franciscano Cachaça', 11934567803),
(8, 1945678937123,'Joãozinho Chupeta', 1134567804);

select * from tbFornecedor;