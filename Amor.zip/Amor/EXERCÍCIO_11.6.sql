use dbDistribuidora;
-- >>> Insert procedure tbEndereco (6)

Delimiter $$

Create procedure spInsert_tbEndereco(
    vLogradouro varchar(200), 
    vBairro varchar(200), 
    vCidade varchar(200), 
    vUF char(2), 
    vCEP decimal(8,0)
)
BEGIN

    IF NOT EXISTS (SELECT BairroId FROM tbBairro WHERE Bairro = vBairro) THEN
        CALL spInsert_tbBairro(vBairro);
    END IF;

    IF NOT EXISTS (SELECT CidadeId FROM tbCidade WHERE Cidade = vCidade) THEN
        CALL spInsert_tbCidade(vCidade);
    END IF;

    IF NOT EXISTS (SELECT UFId FROM tbEstado WHERE UF = vUF) THEN
        CALL spInsert_tbEstado(vUF);
    END IF;

    INSERT INTO tbEndereco (Logradouro, BairroId, CidadeId, UFId, CEP)
    VALUES (
        (SELECT Logradouro from tbFornecedor where Logradouro = vLogradouro),
        (SELECT BairroId FROM tbBairro WHERE Bairro = vBairro),
        (SELECT CidadeId FROM tbCidade WHERE Cidade = vCidade),
        (SELECT UFId FROM tbEstado WHERE UF = vUF),
        vCEP
    );

END $$

drop procedure spInsert_tbEndereco;

call spInsert_tbEndereco('Rua da Federal', 'Lapa', 'São Paulo', 'SP', 12345050);

call spInsert_tbEndereco('Av Brasil', 'Lapa', 'Campinas', 'SP', 12345051);

call spInsert_tbEndereco('Rua Liberdade', 'Consolação', 'São Paulo', 'SP', 12345052);

call spInsert_tbEndereco('Av Paulista', 'Penha', 'Rio de Janeiro', 'RJ', 12345053);

call spInsert_tbEndereco('Rua Ximbú', 'Penha', 'Rio de Janeiro', 'RJ', 12345054);

call spInsert_tbEndereco('Rua Piu XI', 'Penha', 'Campinas', 'SP', 12345055);

call spInsert_tbEndereco('Rua Chocolate', 'Aclimação', 'Barra Mansa', 'RJ', 12345056);

call spInsert_tbEndereco('Rua Pão na Chapa', 'Barra Funda', 'Ponta Grossa', 'RS', 12345057);
