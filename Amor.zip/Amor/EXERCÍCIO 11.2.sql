use dbDistribuidora;
-- >>> Insert procedure tbCidade (2)

Delimiter $$

create procedure spInsert_tbCidade(vCidadeId int,vCidade varchar(200))

BEGIN

insert into tbCidade (Cidade) 
	values (vCidade);

end $$

call spInsert_tbCidade('Rio de Janeiro');
call spInsert_tbCidade('São Carlos');
call spInsert_tbCidade('Campinas');
call spInsert_tbCidade('Franco da Rocha');
call spInsert_tbCidade('Osasco');
call spInsert_tbCidade('Pirituba');
call spInsert_tbCidade('Lapa');
call spInsert_tbCidade('Ponta Grossa');

 select * from tbcidade;

-- DELETE FROM tbcidade;

-- drop procedure spInsert_tbCidade;