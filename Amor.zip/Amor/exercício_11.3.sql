use dbDistribuidora;
-- >>> Insert procedure tbEstado (3)

Delimiter $$

create procedure spInsert_tbEstado(vUF varchar(2))

BEGIN

insert into tbEstado(UF) 
	values (vUF);

end $$

call spInsert_tbEstado('SP');
call spInsert_tbEstado('RJ');
call spInsert_tbEstado('RS');

select * from tbEstado;
