
-- >>> 10?
DELIMITER $$
CREATE PROCEDURE sp_insereVenda( IN num INTEGER, IN cliente INTEGER, IN cod BIGINT, IN qtd INTEGER )
BEGIN
    INSERT INTO tbVenda(NumeroVenda, Id_cli, DataVenda, TotalVenda) SELECT num, cliente, CURDATE(), valor * qtd FROM tbProduto WHERE CodigoBarras = cod;
    INSERT INTO tbItemVenda(NumeroVenda, CodigoBarras, ValorItem, qtd) SELECT num, cod, valor, qtd FROM tbProduto WHERE CodigoBarras = cod;
END $$
DELIMITER ;

CALL sp_insereVenda(1, 1, 12345678910111, 1);
CALL sp_insereVenda(2, 4, 12345678910112, 2);
CALL sp_insereVenda(3, 1, 12345678910113, 1);

DELIMITER $$
CREATE PROCEDURE sp_insereNF( IN nf INTEGER, IN cliente INTEGER )
BEGIN
    INSERT INTO tbNota_fiscal(NF, TotalNota, DataEmissao) SELECT nf, SUM(TotalVenda), CURDATE() FROM tbVenda WHERE Id_cli = cliente;
END $$
DELIMITER ;

CALL sp_insereNF(359, 1);
CALL sp_insereNF(360, 4);

CALL sp_insereProduto(12345678910130, 'Camiseta de Poliéster', 35.61, 100);
CALL sp_insereProduto(12345678910131, 'Blusa Frio Moletom', 200.00, 100);
CALL sp_insereProduto(12345678910132, 'Vestido Decote Redondo', 144.00, 50);

DELIMITER $$
CREATE PROCEDURE sp_deletaProduto( IN cod BIGINT )
BEGIN
    DELETE FROM tbProduto WHERE cod_barras = cod;
END $$
DELIMITER ;

CALL sp_deletaProduto(12345678910116);
CALL sp_deletaProduto(12345678910117);

DELIMITER $$
CREATE PROCEDURE sp_atualizaProduto( IN cod BIGINT, IN novo_nome VARCHAR(200), IN novo_valor DECIMAL(12,2) )
BEGIN
    UPDATE tbProduto SET nome = novo_nome, valor = novo_valor WHERE cod_barras = cod;
END $$
DELIMITER ;

CALL sp_atualizaProduto(12345678910111, 'Rei de Papel Mache', 64.50);
CALL sp_atualizaProduto(12345678910112, 'Bolinha de Sabão', 120.00);
CALL sp_atualizaProduto(12345678910113, 'Carro Bate Bate', 64.00);

DELIMITER $$
CREATE PROCEDURE sp_listaProdutos()
BEGIN
    SELECT * FROM tbProduto;
END $$
DELIMITER ;

CALL sp_listaProdutos();
